# Healing Cult — launch starter

This is a deployable static-site starter with your founder portrait, a research feed, animal groups, a profile page, and a Supabase integration scaffold.

## Important current status
- The site can be deployed as a public static website.
- Before you configure Supabase, accounts and posts are demo/local-browser behavior only.
- The SQL schema includes secure row-level policies for core tables.
- This starter is not a clinical research platform, medical service, or substitute for a security review. It is not yet a fully production-hardened social network.

## 1. Create a Supabase project
1. Go to https://supabase.com/ and create a project.
2. In Project Settings / API, copy the Project URL and publishable/anon key.
3. Open SQL Editor and run all of `supabase/schema.sql`.
4. In Authentication settings, set the site URL to your eventual deployed URL and configure allowed redirect URLs.
5. For an initial public launch, consider requiring email confirmation and configure SMTP before inviting users.
6. In `index.html`, set `SUPABASE_URL` and `SUPABASE_ANON_KEY`. The publishable/anon key is intended for browser use with RLS enabled. Never use `service_role` or secret keys in frontend code.

## 2. Deploy the site
### Netlify (simple static deployment)
1. Create a GitHub repository and add `index.html`, `assets/founder.jpg`, and `supabase/schema.sql`.
2. Push the repository to GitHub.
3. Sign in at https://www.netlify.com/ and choose Add new site / Import an existing project.
4. Select the repository. Build command can be empty; publish directory is the repository root.
5. Deploy. Netlify will provide a public `*.netlify.app` URL.
6. Add that URL to Supabase Authentication Site URL and Redirect URLs, then redeploy if you change frontend settings.

### Vercel
1. Import the GitHub repository at https://vercel.com/.
2. Use the root as the project directory; no build command is required for this static starter.
3. Deploy and copy the public URL.
4. Add the URL to Supabase Authentication settings.

## 3. Verify before inviting people
- Open the site in a private/incognito window and confirm it loads.
- Create two test accounts with email addresses you control.
- Confirm each can sign in, publish a post, edit their own profile, join/leave a group, and see shared posts.
- Verify user A cannot edit user B's profile or delete user B's posts.
- Test email confirmation, password reset, mobile layout, and links.
- Review Supabase logs and database policies.
- Set up backups, abuse reporting, moderator workflow, contact email, privacy policy, and terms before broad public promotion.

## 4. Google search
1. Use the hosting URL or connect a domain you own.
2. Add a sitemap and robots.txt appropriate to the final domain.
3. Visit https://search.google.com/search-console/about and verify domain ownership.
4. Submit the sitemap and request indexing. Search indexing can take time and is not guaranteed.

## 5. Safety and transparency before public recruitment
- Publish clear community guidelines and a way to report harmful or misleading posts.
- Label hypotheses, preprints, peer-reviewed studies, and established clinical guidance separately.
- Require citations and disclose conflicts of interest.
- Do not solicit personal medical records or private health details in public posts.
- Do not publish instructions for dangerous toxin handling or encourage testing unproven treatments on people or animals.
- Obtain qualified institutional and ethics oversight for experiments involving people or animals.
- Be honest about qualifications; student status is not a clinical credential.

## File map
- `index.html`: front end and Supabase client integration points
- `assets/founder.jpg`: founder portrait supplied for the profile
- `supabase/schema.sql`: tables, auth trigger, and row-level security policies

## Known limitations in this starter
The prototype currently implements sign-in/sign-up, profile upsert, post creation/listing, and group membership once Supabase is configured. Comments are represented in the schema but the UI still needs a comment interface; likes are basic; moderation workflow, password reset UI, user avatar upload, admin role management, rate limiting, and automated tests still need implementation before calling it production-ready.
