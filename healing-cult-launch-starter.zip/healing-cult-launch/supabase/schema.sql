-- Healing Cult starter schema for Supabase (Postgres)
-- Run this in Supabase Dashboard > SQL Editor. Review before production use.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Community member' check (char_length(display_name) <= 80),
  bio text not null default '' check (char_length(bio) <= 1000),
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.memberships (
  user_id uuid not null references auth.users(id) on delete cascade,
  group_name text not null check (group_name in ('Serpent','Owl','Fox','Elephant','Bee','Turtle')),
  joined_at timestamptz not null default now(),
  primary key (user_id, group_name)
);

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 140),
  type text not null check (type in ('Ideation / hypothesis','Literature review','Preliminary observation','Peer-reviewed finding','Myth check')),
  group_name text not null default 'Open community' check (group_name in ('Serpent','Owl','Fox','Elephant','Bee','Turtle','Open community')),
  body text not null check (char_length(body) between 1 and 10000),
  source_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.likes (
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (post_id, user_id)
);

create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 3000),
  created_at timestamptz not null default now()
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references auth.users(id) on delete cascade,
  post_id uuid references public.posts(id) on delete cascade,
  reason text not null check (char_length(reason) between 5 and 1000),
  status text not null default 'open' check (status in ('open','reviewing','resolved','dismissed')),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.memberships enable row level security;
alter table public.posts enable row level security;
alter table public.likes enable row level security;
alter table public.comments enable row level security;
alter table public.reports enable row level security;

-- Public reading; authenticated users can only modify their own rows.
create policy "profiles are public to read" on public.profiles for select using (true);
create policy "users create own profile" on public.profiles for insert to authenticated with check (auth.uid() = id);
create policy "users update own profile" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

create policy "memberships are public to read" on public.memberships for select using (true);
create policy "users join groups as self" on public.memberships for insert to authenticated with check (auth.uid() = user_id);
create policy "users leave own groups" on public.memberships for delete to authenticated using (auth.uid() = user_id);

create policy "posts are public to read" on public.posts for select using (true);
create policy "signed-in users create own posts" on public.posts for insert to authenticated with check (auth.uid() = user_id);
create policy "authors update own posts" on public.posts for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "authors delete own posts" on public.posts for delete to authenticated using (auth.uid() = user_id);

create policy "likes are public to read" on public.likes for select using (true);
create policy "users add own likes" on public.likes for insert to authenticated with check (auth.uid() = user_id);
create policy "users remove own likes" on public.likes for delete to authenticated using (auth.uid() = user_id);

create policy "comments are public to read" on public.comments for select using (true);
create policy "signed-in users comment as self" on public.comments for insert to authenticated with check (auth.uid() = user_id);
create policy "authors update own comments" on public.comments for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "authors delete own comments" on public.comments for delete to authenticated using (auth.uid() = user_id);

create policy "users see own reports" on public.reports for select to authenticated using (auth.uid() = reporter_id);
create policy "users submit reports" on public.reports for insert to authenticated with check (auth.uid() = reporter_id);

-- Create a profile row whenever a new user signs up.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'display_name', 'Community member'));
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Helpful index for newest-first feed.
create index if not exists posts_created_at_idx on public.posts (created_at desc);
create index if not exists comments_post_id_idx on public.comments (post_id, created_at);
